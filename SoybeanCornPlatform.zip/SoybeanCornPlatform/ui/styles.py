"""
UI 样式表 - 大豆玉米植保移动平台可视化
"""

PRIMARY_COLOR = "#2E7D32"      # 植保绿
SECONDARY_COLOR = "#66BB6A"    # 浅绿
ACCENT_COLOR = "#4ECDC4"       # 青色
WARNING_COLOR = "#FFA726"      # 橙色
DANGER_COLOR = "#EF5350"       # 红色

STYLESHEET = """
QMainWindow {
    background-color: #0D1117;
}

QWidget {
    font-family: "Microsoft YaHei UI", "Segoe UI", sans-serif;
    font-size: 12px;
    color: #E6EDF3;
}

QFrame#sideBar {
    background-color: #161B22;
    border-right: 1px solid #21262D;
}

QComboBox {
    background-color: #21262D;
    color: #E6EDF3;
    border: 1px solid #30363D;
    border-radius: 6px;
    padding: 8px 12px;
    min-width: 120px;
}

QComboBox:hover {
    border-color: #2E7D32;
    background-color: #1C2128;
}

QComboBox::drop-down {
    border: none;
    padding-right: 10px;
}

QComboBox QAbstractItemView {
    background-color: #161B22;
    color: #E6EDF3;
    selection-background-color: #2E7D32;
    border: 1px solid #30363D;
    border-radius: 6px;
    padding: 4px;
}

QCheckBox {
    color: #8B949E;
    spacing: 8px;
}

QCheckBox::indicator {
    width: 20px;
    height: 20px;
    border-radius: 4px;
    border: 2px solid #30363D;
    background-color: transparent;
}

QCheckBox::indicator:checked {
    background-color: #2E7D32;
    border-color: #2E7D32;
}

QProgressBar {
    background-color: #21262D;
    border: none;
    border-radius: 4px;
    height: 6px;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #2E7D32, stop:1 #66BB6A);
    border-radius: 4px;
}

QMenu {
    background-color: #161B22;
    color: #E6EDF3;
    border: 1px solid #30363D;
    border-radius: 6px;
    padding: 5px;
}

QMenu::item {
    padding: 8px 20px;
    border-radius: 4px;
}

QMenu::item:selected {
    background-color: #2E7D32;
}
"""


def get_full_stylesheet() -> str:
    return STYLESHEET
