"""
主窗口 - 大豆玉米植保移动平台可视化
"""

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QLabel, QPushButton, QComboBox, QCheckBox, QProgressBar,
    QFileDialog, QMenu, QMessageBox, QApplication
)
from PySide6.QtCore import Qt, QThread, Signal, QPoint
from PySide6.QtGui import QAction
import numpy as np
import os
import time

from .styles import get_full_stylesheet, ACCENT_COLOR
from .widgets import (
    StatsCard, VideoDisplay, SidebarButton, ControlButton, LabeledSlider, DutyCycleBar
)


class DetectionThread(QThread):
    """检测线程"""

    frame_ready = Signal(np.ndarray, np.ndarray, list)
    progress = Signal(int)
    status = Signal(str)
    fps_update = Signal(float)
    process_fps_update = Signal(float)
    finished_detection = Signal()
    error = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.detector = None
        self.source = None
        self.is_running = False
        self.is_paused = False

    def set_detector(self, detector):
        self.detector = detector

    def set_source(self, source):
        self.source = source

    def run(self):
        if self.detector is None or self.source is None:
            self.error.emit("检测器或输入源未设置")
            return

        from utils.camera import VideoCapture
        from utils.general import FPSCounter

        self.is_running = True
        fps_counter = FPSCounter(avg_count=10)
        process_fps_counter = FPSCounter(avg_count=10)

        try:
            cap = VideoCapture(self.source)
            if not cap.open():
                self.error.emit(f"无法打开: {self.source}")
                return

            self.status.emit("检测中...")
            info = cap.get_info()
            total_frames = info['frame_count'] if info['frame_count'] > 0 else -1
            frame_count = 0

            while self.is_running:
                if self.is_paused:
                    time.sleep(0.1)
                    continue

                ret, frame = cap.read()
                if not ret:
                    break

                frame_count += 1

                # 处理FPS - 只计算推理耗时
                t_start = time.time()
                detections = self.detector.detect(frame)
                t_end = time.time()
                result_frame = self.detector.draw_detections(frame, detections)

                self.frame_ready.emit(frame.copy(), result_frame, detections)

                # 整体FPS
                fps = fps_counter.update()
                self.fps_update.emit(fps)

                # 处理FPS
                process_time = t_end - t_start
                process_fps = 1.0 / process_time if process_time > 0 else 0
                self.process_fps_update.emit(process_fps)

                if total_frames > 0:
                    progress = int(frame_count / total_frames * 100)
                    self.progress.emit(progress)

            cap.release()

        except Exception as e:
            self.error.emit(str(e))
        finally:
            self.is_running = False
            self.finished_detection.emit()
            self.status.emit("检测完成")

    def stop(self):
        self.is_running = False

    def pause(self):
        self.is_paused = True

    def resume(self):
        self.is_paused = False


class MainWindow(QMainWindow):
    """主窗口 - 大豆玉米植保移动平台可视化"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("大豆玉米植保移动平台可视化")
        self.setMinimumSize(1400, 800)

        self.detector = None
        self.current_source = None
        self.is_detecting = False

        self.setStyleSheet(get_full_stylesheet())
        self._setup_ui()

        self.detection_thread = DetectionThread()
        self._connect_signals()

        self._load_config()
        self._refresh_models()

    def _setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 左侧边栏
        sidebar = self._create_sidebar()
        main_layout.addWidget(sidebar)

        # 右侧内容区
        content = self._create_content()
        main_layout.addWidget(content, 1)

    # =====================================================
    #  侧边栏（与原版结构一致，仅更新名称和配色）
    # =====================================================
    def _create_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sideBar")
        sidebar.setFixedWidth(220)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(15, 20, 15, 20)
        layout.setSpacing(10)

        # Logo / 标题
        title_layout = QHBoxLayout()
        logo = QLabel("🌿")
        logo.setStyleSheet("font-size: 26px;")
        title = QLabel("植保平台")
        title.setStyleSheet("font-size: 17px; font-weight: bold; color: #E6EDF3;")
        title_layout.addWidget(logo)
        title_layout.addWidget(title)
        title_layout.addStretch()
        layout.addLayout(title_layout)

        layout.addSpacing(20)

        # 输入源
        source_label = QLabel("输入源")
        source_label.setStyleSheet("color: #484F58; font-size: 11px; font-weight: bold;")
        layout.addWidget(source_label)

        self.btn_file = SidebarButton("本地文件", "📁")
        self.btn_file.clicked.connect(self._open_file)
        layout.addWidget(self.btn_file)

        self.btn_camera = SidebarButton("摄像头", "📷")
        self.btn_camera.clicked.connect(self._open_camera)
        layout.addWidget(self.btn_camera)

        self.btn_rtsp = SidebarButton("RTSP 流", "🌐")
        self.btn_rtsp.clicked.connect(self._open_rtsp)
        layout.addWidget(self.btn_rtsp)

        layout.addSpacing(20)

        # 模型
        model_label = QLabel("模型")
        model_label.setStyleSheet("color: #484F58; font-size: 11px; font-weight: bold;")
        layout.addWidget(model_label)

        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(40)
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        layout.addWidget(self.model_combo)

        layout.addSpacing(20)

        # 参数设置
        params_label = QLabel("参数设置")
        params_label.setStyleSheet("color: #484F58; font-size: 11px; font-weight: bold;")
        layout.addWidget(params_label)

        self.conf_slider = LabeledSlider("置信度", 0.0, 1.0, 0.25, decimals=2)
        self.conf_slider.valueChanged.connect(self._on_conf_changed)
        layout.addWidget(self.conf_slider)

        self.iou_slider = LabeledSlider("IOU 阈值", 0.0, 1.0, 0.45, decimals=2)
        self.iou_slider.valueChanged.connect(self._on_iou_changed)
        layout.addWidget(self.iou_slider)

        layout.addSpacing(20)

        # 保存选项
        save_label = QLabel("保存选项")
        save_label.setStyleSheet("color: #484F58; font-size: 11px; font-weight: bold;")
        layout.addWidget(save_label)

        self.save_img_check = QCheckBox("保存图片")
        layout.addWidget(self.save_img_check)

        self.save_video_check = QCheckBox("保存视频")
        layout.addWidget(self.save_video_check)

        layout.addStretch()

        version = QLabel("v1.0.0 | ONNX Runtime")
        version.setStyleSheet("color: #484F58; font-size: 10px;")
        version.setAlignment(Qt.AlignCenter)
        layout.addWidget(version)

        return sidebar

    # =====================================================
    #  右侧内容区（重新设计）
    # =====================================================
    def _create_content(self) -> QFrame:
        content = QFrame()
        content.setStyleSheet("background-color: #0D1117;")

        layout = QVBoxLayout(content)
        layout.setContentsMargins(16, 14, 16, 10)
        layout.setSpacing(10)

        # ---- 顶部: 标题 + FPS卡片 ----
        top_bar = QHBoxLayout()
        top_bar.setSpacing(12)

        header_label = QLabel("大豆玉米植保移动平台可视化")
        header_label.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #E6EDF3; padding-left: 4px;"
        )
        top_bar.addWidget(header_label)
        top_bar.addStretch()

        self.card_fps = StatsCard("FPS", "--", "#4ECDC4")
        self.card_fps.setFixedWidth(120)
        top_bar.addWidget(self.card_fps)

        self.card_process_fps = StatsCard("处理 FPS", "--", "#66BB6A")
        self.card_process_fps.setFixedWidth(120)
        top_bar.addWidget(self.card_process_fps)

        layout.addLayout(top_bar)

        # ---- 三个视频窗口并排 ----
        video_container = QFrame()
        video_container.setStyleSheet("""
            QFrame {
                background-color: #161B22;
                border: 1px solid #21262D;
                border-radius: 10px;
            }
        """)
        video_layout = QHBoxLayout(video_container)
        video_layout.setContentsMargins(10, 10, 10, 10)
        video_layout.setSpacing(10)

        # 窗口1: 原始视频
        original_frame = self._make_video_panel("原始视频")
        self.original_display = original_frame.findChild(VideoDisplay)
        video_layout.addWidget(original_frame, 1)

        # 窗口2: 识别效果
        result_frame = self._make_video_panel("识别效果")
        self.result_display = result_frame.findChild(VideoDisplay)
        video_layout.addWidget(result_frame, 1)

        # 窗口3: 规划导航线
        nav_frame = self._make_video_panel("规划导航线")
        self.nav_display = nav_frame.findChild(VideoDisplay)
        video_layout.addWidget(nav_frame, 1)

        layout.addWidget(video_container, 1)   # stretch=1 让视频区尽量大

        # ---- 底部区域: 占空比 + 控制按钮 ----
        bottom_container = QFrame()
        bottom_container.setStyleSheet("""
            QFrame {
                background-color: #161B22;
                border: 1px solid #21262D;
                border-radius: 10px;
            }
        """)
        bottom_layout = QVBoxLayout(bottom_container)
        bottom_layout.setContentsMargins(16, 10, 16, 10)
        bottom_layout.setSpacing(8)

        # 占空比指示条
        self.duty_cycle_bar = DutyCycleBar()
        bottom_layout.addWidget(self.duty_cycle_bar)

        # 分割线
        sep = QFrame()
        sep.setFixedHeight(1)
        sep.setStyleSheet("background-color: #21262D; border: none;")
        bottom_layout.addWidget(sep)

        # 控制栏
        control_layout = QHBoxLayout()
        control_layout.setSpacing(12)

        self.btn_start = ControlButton("▶  开始", "success")
        self.btn_start.clicked.connect(self._toggle_detection)
        control_layout.addWidget(self.btn_start)

        self.btn_stop = ControlButton("■  停止", "danger")
        self.btn_stop.clicked.connect(self._stop_detection)
        self.btn_stop.setEnabled(False)
        control_layout.addWidget(self.btn_stop)

        self.btn_screenshot = ControlButton("📷  截图", "default")
        self.btn_screenshot.clicked.connect(self._take_screenshot)
        control_layout.addWidget(self.btn_screenshot)

        control_layout.addStretch()

        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setTextVisible(False)
        control_layout.addWidget(self.progress_bar, 1)

        bottom_layout.addLayout(control_layout)

        # 状态栏
        self.status_label = QLabel("就绪")
        self.status_label.setStyleSheet("color: #484F58; font-size: 11px; border: none;")
        bottom_layout.addWidget(self.status_label)

        layout.addWidget(bottom_container)

        return content

    def _make_video_panel(self, title_text: str) -> QFrame:
        """创建一个带标题的视频面板"""
        frame = QFrame()
        frame.setStyleSheet("""
            QFrame {
                background-color: #0D1117;
                border: 1px solid #21262D;
                border-radius: 8px;
            }
        """)
        panel_layout = QVBoxLayout(frame)
        panel_layout.setContentsMargins(6, 4, 6, 6)
        panel_layout.setSpacing(4)

        title = QLabel(title_text)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #8B949E; font-size: 11px; font-weight: bold; border: none;")
        panel_layout.addWidget(title)

        display = VideoDisplay()
        display.set_placeholder(title_text)
        panel_layout.addWidget(display, 1)

        return frame

    # =====================================================
    #  信号连接
    # =====================================================
    def _connect_signals(self):
        self.detection_thread.frame_ready.connect(self._on_frame_ready)
        self.detection_thread.progress.connect(self._on_progress)
        self.detection_thread.status.connect(self._on_status)
        self.detection_thread.fps_update.connect(self._on_fps_update)
        self.detection_thread.process_fps_update.connect(self._on_process_fps_update)
        self.detection_thread.finished_detection.connect(self._on_detection_finished)
        self.detection_thread.error.connect(self._on_error)

    # =====================================================
    #  配置与模型
    # =====================================================
    def _load_config(self):
        from utils.general import load_json
        config = load_json("config/setting.json")

        if config:
            self.conf_slider.set_value(config.get('conf', 0.25))
            self.iou_slider.set_value(config.get('iou', 0.45))
            self.save_img_check.setChecked(config.get('save_img', False))
            self.save_video_check.setChecked(config.get('save_video', False))

    def _save_config(self):
        from utils.general import save_json
        config = {
            'conf': self.conf_slider.value(),
            'iou': self.iou_slider.value(),
            'save_img': self.save_img_check.isChecked(),
            'save_video': self.save_video_check.isChecked(),
            'model': self.model_combo.currentText()
        }
        save_json("config/setting.json", config)

    def _refresh_models(self):
        from utils.general import list_models
        models = list_models("models", ['.onnx'])

        self.model_combo.clear()
        if models:
            self.model_combo.addItems(models)
            self._load_model(models[0])
        else:
            self.status_label.setText("未在 'models' 文件夹中找到模型")

    def _load_model(self, model_name: str):
        model_path = f"models/{model_name}"

        if not os.path.exists(model_path):
            self._on_error(f"模型未找到: {model_path}")
            return

        try:
            self.status_label.setText(f"正在加载模型: {model_name}...")
            QApplication.processEvents()

            from core import ONNXDetector
            self.detector = ONNXDetector(
                model_path,
                conf_thres=self.conf_slider.value(),
                iou_thres=self.iou_slider.value()
            )

            self.detection_thread.set_detector(self.detector)

            info = self.detector.get_model_info()
            self.status_label.setText(f"模型已加载: {model_name} | 运行环境: {info['provider']}")

        except Exception as e:
            self._on_error(f"加载模型失败: {e}")

    # =====================================================
    #  输入源
    # =====================================================
    def _open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "打开文件", "",
            "媒体文件 (*.mp4 *.avi *.mkv *.mov *.jpg *.jpeg *.png *.bmp);;所有文件 (*)"
        )

        if file_path:
            self.current_source = file_path
            self.status_label.setText(f"已选择: {os.path.basename(file_path)}")
            self._clear_buttons()
            self.btn_file.setChecked(True)

    def _open_camera(self):
        menu = QMenu(self)
        for cam_id in range(4):
            action = QAction(f"摄像头 {cam_id}", self)
            action.triggered.connect(lambda checked, cid=cam_id: self._select_camera(cid))
            menu.addAction(action)

        menu.exec(self.btn_camera.mapToGlobal(QPoint(0, self.btn_camera.height())))

    def _select_camera(self, camera_id: int):
        self.current_source = camera_id
        self.status_label.setText(f"已选择: 摄像头 {camera_id}")
        self._clear_buttons()
        self.btn_camera.setChecked(True)

    def _open_rtsp(self):
        from PySide6.QtWidgets import QInputDialog

        rtsp_url, ok = QInputDialog.getText(
            self, "RTSP 流",
            "请输入 RTSP 地址:",
            text="rtsp://admin:password@192.168.1.100:554/stream"
        )

        if ok and rtsp_url:
            self.current_source = rtsp_url
            self.status_label.setText(f"已选择: RTSP 流")
            self._clear_buttons()
            self.btn_rtsp.setChecked(True)

    def _clear_buttons(self):
        self.btn_file.setChecked(False)
        self.btn_camera.setChecked(False)
        self.btn_rtsp.setChecked(False)

    # =====================================================
    #  检测控制
    # =====================================================
    def _toggle_detection(self):
        if self.is_detecting:
            self.detection_thread.pause()
            self.btn_start.setText("▶  继续")
            self.is_detecting = False
        else:
            if self.detection_thread.isRunning():
                self.detection_thread.resume()
                self.btn_start.setText("⏸  暂停")
                self.is_detecting = True
            else:
                self._start_detection()

    def _start_detection(self):
        if self.detector is None:
            QMessageBox.warning(self, "警告", "请先加载模型")
            return

        if self.current_source is None:
            QMessageBox.warning(self, "警告", "请先选择输入源")
            return

        self.detection_thread.set_source(self.current_source)
        self.detection_thread.start()

        self.btn_start.setText("⏸  暂停")
        self.btn_stop.setEnabled(True)
        self.is_detecting = True

    def _stop_detection(self):
        self.detection_thread.stop()
        self.detection_thread.wait()
        self._reset_ui()

    def _reset_ui(self):
        self.btn_start.setText("▶  开始")
        self.btn_stop.setEnabled(False)
        self.is_detecting = False
        self.progress_bar.setValue(0)
        self.original_display.clear_display()
        self.result_display.clear_display()
        self.nav_display.clear_display()
        self.card_fps.set_value("--")
        self.card_process_fps.set_value("--")
        self.duty_cycle_bar.set_diff(0)

    def _take_screenshot(self):
        if self.result_display.pixmap() and not self.result_display.pixmap().isNull():
            from utils.general import ensure_dir, get_timestamp

            save_dir = ensure_dir("outputs/screenshots")
            filename = f"screenshot_{get_timestamp()}.png"
            filepath = save_dir / filename

            self.result_display.pixmap().save(str(filepath))
            self.status_label.setText(f"截图已保存: {filename}")
        else:
            self.status_label.setText("没有可截取的画面")

    # =====================================================
    #  参数变更
    # =====================================================
    def _on_model_changed(self, model_name: str):
        if model_name:
            self._load_model(model_name)

    def _on_conf_changed(self, value: float):
        if self.detector:
            self.detector.conf_thres = value

    def _on_iou_changed(self, value: float):
        if self.detector:
            self.detector.iou_thres = value

    # =====================================================
    #  回调：检测结果
    # =====================================================
    def _on_frame_ready(self, original: np.ndarray, result: np.ndarray, detections: list):
        self.original_display.set_frame(original)
        self.result_display.set_frame(result)

        # 导航线窗口 - 目前占位，后续在此接入导航线绘制逻辑
        # 示例：直接显示原始帧的副本，后续替换为导航线绘制结果
        self.nav_display.set_frame(original)

        # 占空比 - 目前占位，后续在此接入实际占空比数据
        # 示例：self.duty_cycle_bar.set_value(left_duty, right_duty)
        # 或:   self.duty_cycle_bar.set_diff(diff_value)

    def _on_progress(self, value: int):
        self.progress_bar.setValue(value)

    def _on_status(self, message: str):
        self.status_label.setText(message)

    def _on_fps_update(self, fps: float):
        self.card_fps.set_value(f"{fps:.1f}")

    def _on_process_fps_update(self, fps: float):
        self.card_process_fps.set_value(f"{fps:.1f}")

    def _on_detection_finished(self):
        self._reset_ui()

    def _on_error(self, message: str):
        self.status_label.setText(f"错误: {message}")
        QMessageBox.critical(self, "错误", message)

    def closeEvent(self, event):
        if self.detection_thread.isRunning():
            self.detection_thread.stop()
            self.detection_thread.wait()
        self._save_config()
        event.accept()

    # =====================================================
    #  公开接口：供外部模块调用
    # =====================================================
    def update_nav_frame(self, frame: np.ndarray):
        """外部调用：更新导航线窗口画面"""
        self.nav_display.set_frame(frame)

    def update_duty_cycle(self, left_duty: float, right_duty: float):
        """外部调用：更新左右轮占空比"""
        self.duty_cycle_bar.set_value(left_duty, right_duty)

    def update_duty_cycle_diff(self, diff: float):
        """外部调用：直接设置占空比差值"""
        self.duty_cycle_bar.set_diff(diff)
