"""
自定义控件 - 大豆玉米植保移动平台可视化
"""

from PySide6.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QFrame, QPushButton, QSizePolicy, QSlider
)
from PySide6.QtCore import Qt, Signal, QRectF
from PySide6.QtGui import QPixmap, QImage, QPainter, QColor, QLinearGradient, QFont, QPen, QBrush
import numpy as np
import cv2


class StatsCard(QFrame):
    """统计卡片"""

    def __init__(self, title: str, value: str = "--", color: str = "#4ECDC4", parent=None):
        super().__init__(parent)
        self.color = color
        self._setup_ui(title, value)

    def _setup_ui(self, title: str, value: str):
        self.setStyleSheet("""
            QFrame {
                background-color: #161B22;
                border: 1px solid #21262D;
                border-radius: 10px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(2)

        self.value_label = QLabel(value)
        self.value_label.setAlignment(Qt.AlignCenter)
        self.value_label.setStyleSheet(f"color: {self.color}; font-size: 22px; font-weight: bold; border: none;")
        layout.addWidget(self.value_label)

        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet("color: #8B949E; font-size: 11px; border: none;")
        layout.addWidget(self.title_label)

        self.setMinimumSize(90, 65)
        self.setMaximumHeight(75)

    def set_value(self, value: str):
        self.value_label.setText(str(value))


class VideoDisplay(QLabel):
    """视频显示"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(200, 150)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setStyleSheet("""
            background-color: #010409;
            border-radius: 6px;
            color: #484F58;
            font-size: 13px;
        """)
        self._default_text = "No Video"
        self.setText(self._default_text)

    def set_frame(self, frame: np.ndarray):
        if frame is None:
            self.clear_display()
            return

        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return

        img_h, img_w = frame.shape[:2]
        scale = min(w / img_w, h / img_h)
        new_w, new_h = int(img_w * scale), int(img_h * scale)

        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        rgb_frame = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)

        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        qimg = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.setPixmap(QPixmap.fromImage(qimg))

    def clear_display(self):
        self.clear()
        self.setText(self._default_text)

    def set_placeholder(self, text: str):
        self._default_text = text
        if self.pixmap() is None or self.pixmap().isNull():
            self.setText(text)


class SidebarButton(QPushButton):
    """侧边栏按钮"""

    def __init__(self, text: str, icon_text: str = "", parent=None):
        super().__init__(parent)
        self.setText(f"  {icon_text}  {text}" if icon_text else f"  {text}")
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(42)
        self.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #8B949E;
                border: none;
                border-radius: 8px;
                text-align: left;
                padding-left: 15px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: rgba(46, 125, 50, 0.15);
                color: #E6EDF3;
            }
            QPushButton:checked {
                background-color: #2E7D32;
                color: #FFFFFF;
            }
        """)


class ControlButton(QPushButton):
    """控制按钮"""

    def __init__(self, text: str, button_type: str = "default", parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumSize(80, 38)

        colors = {
            "default": ("#21262D", "#2E7D32"),
            "success": ("#2E7D32", "#388E3C"),
            "danger": ("#D9534F", "#E87C79"),
        }

        bg, hover = colors.get(button_type, colors["default"])

        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 20px;
                font-size: 13px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {hover};
            }}
            QPushButton:disabled {{
                background-color: #161B22;
                color: #484F58;
            }}
        """)


class LabeledSlider(QWidget):
    """带标签的滑块"""

    valueChanged = Signal(float)

    def __init__(self, label: str, min_val: float, max_val: float,
                 default: float, decimals: int = 2, parent=None):
        super().__init__(parent)

        self.min_val = min_val
        self.max_val = max_val
        self.decimals = decimals
        self.multiplier = 10 ** decimals

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        label_layout = QHBoxLayout()
        self.label = QLabel(label)
        self.label.setStyleSheet("color: #8B949E; font-size: 12px;")
        self.value_label = QLabel(f"{default:.{decimals}f}")
        self.value_label.setStyleSheet("color: #66BB6A; font-size: 12px; font-weight: bold;")
        label_layout.addWidget(self.label)
        label_layout.addStretch()
        label_layout.addWidget(self.value_label)
        layout.addLayout(label_layout)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(int(min_val * self.multiplier))
        self.slider.setMaximum(int(max_val * self.multiplier))
        self.slider.setValue(int(default * self.multiplier))
        self.slider.valueChanged.connect(self._on_value_changed)
        self.slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 6px;
                background: #21262D;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                width: 16px;
                height: 16px;
                margin: -5px 0;
                background: #2E7D32;
                border-radius: 8px;
            }
            QSlider::sub-page:horizontal {
                background: #2E7D32;
                border-radius: 3px;
            }
        """)
        layout.addWidget(self.slider)

    def _on_value_changed(self, value: int):
        real_value = value / self.multiplier
        self.value_label.setText(f"{real_value:.{self.decimals}f}")
        self.valueChanged.emit(real_value)

    def value(self) -> float:
        return self.slider.value() / self.multiplier

    def set_value(self, value: float):
        self.slider.setValue(int(value * self.multiplier))


class DutyCycleBar(QWidget):
    """
    左右轮占空比差值 - 对称水平指示条
    差值范围: -100 ~ +100
    负值偏左（左轮占空比大），正值偏右（右轮占空比大），0为正中
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._value = 0.0          # 差值
        self._left_duty = 50.0     # 左轮占空比
        self._right_duty = 50.0    # 右轮占空比
        self.setMinimumHeight(90)
        self.setMaximumHeight(110)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_value(self, left_duty: float, right_duty: float):
        """设置左右轮占空比，自动计算差值"""
        self._left_duty = left_duty
        self._right_duty = right_duty
        self._value = right_duty - left_duty
        self.update()

    def set_diff(self, diff: float):
        """直接设置差值"""
        self._value = max(-100, min(100, diff))
        self._left_duty = 50 - diff / 2
        self._right_duty = 50 + diff / 2
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()
        margin_x = 20
        bar_y = 18
        bar_h = 24
        bar_w = w - margin_x * 2
        center_x = w / 2

        # --- 标题行 ---
        painter.setPen(QColor("#8B949E"))
        title_font = QFont("Microsoft YaHei UI", 10)
        painter.setFont(title_font)
        painter.drawText(QRectF(0, 0, w, bar_y), Qt.AlignCenter, "左右轮占空比差值")

        # --- 背景槽 ---
        bar_rect = QRectF(margin_x, bar_y, bar_w, bar_h)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#21262D"))
        painter.drawRoundedRect(bar_rect, bar_h / 2, bar_h / 2)

        # --- 中线 ---
        painter.setPen(QPen(QColor("#484F58"), 2))
        painter.drawLine(int(center_x), bar_y + 2, int(center_x), bar_y + bar_h - 2)

        # --- 填充条 ---
        ratio = self._value / 100.0
        fill_px = abs(ratio) * (bar_w / 2)

        if self._value >= 0:
            # 偏右 - 从中心向右填充 (绿色)
            fill_rect = QRectF(center_x, bar_y + 3, fill_px, bar_h - 6)
            grad = QLinearGradient(center_x, 0, center_x + fill_px, 0)
            grad.setColorAt(0, QColor("#2E7D32"))
            grad.setColorAt(1, QColor("#66BB6A"))
        else:
            # 偏左 - 从中心向左填充 (橙色)
            fill_rect = QRectF(center_x - fill_px, bar_y + 3, fill_px, bar_h - 6)
            grad = QLinearGradient(center_x - fill_px, 0, center_x, 0)
            grad.setColorAt(0, QColor("#FFA726"))
            grad.setColorAt(1, QColor("#FB8C00"))

        painter.setBrush(QBrush(grad))
        painter.drawRoundedRect(fill_rect, (bar_h - 6) / 2, (bar_h - 6) / 2)

        # --- 指示三角 ---
        indicator_x = center_x + ratio * (bar_w / 2)
        indicator_x = max(margin_x + 5, min(w - margin_x - 5, indicator_x))
        tri_y = bar_y + bar_h + 4
        from PySide6.QtGui import QPolygonF
        from PySide6.QtCore import QPointF
        triangle = QPolygonF([
            QPointF(indicator_x, tri_y),
            QPointF(indicator_x - 5, tri_y + 8),
            QPointF(indicator_x + 5, tri_y + 8),
        ])
        painter.setBrush(QColor("#E6EDF3"))
        painter.setPen(Qt.NoPen)
        painter.drawPolygon(triangle)

        # --- 差值数字 ---
        val_font = QFont("Microsoft YaHei UI", 14, QFont.Bold)
        painter.setFont(val_font)
        diff_text = f"{self._value:+.1f}%"
        if abs(self._value) < 0.1:
            painter.setPen(QColor("#66BB6A"))
        elif self._value > 0:
            painter.setPen(QColor("#66BB6A"))
        else:
            painter.setPen(QColor("#FFA726"))
        painter.drawText(QRectF(0, tri_y + 6, w, 24), Qt.AlignCenter, diff_text)

        # --- 左右标签 ---
        label_font = QFont("Microsoft YaHei UI", 9)
        painter.setFont(label_font)
        painter.setPen(QColor("#8B949E"))

        left_text = f"左轮 {self._left_duty:.1f}%"
        right_text = f"右轮 {self._right_duty:.1f}%"
        label_y = tri_y + 28
        painter.drawText(QRectF(margin_x, label_y, bar_w / 2, 16), Qt.AlignLeft | Qt.AlignVCenter, left_text)
        painter.drawText(QRectF(center_x, label_y, bar_w / 2, 16), Qt.AlignRight | Qt.AlignVCenter, right_text)

        painter.end()
