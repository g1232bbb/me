#!/usr/bin/env python3
"""
大豆玉米植保移动平台可视化
基于 ONNX Runtime
"""

import sys
import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT_DIR)

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont


def setup_environment():
    dirs = ['config', 'models', 'outputs', 'outputs/screenshots', 'outputs/videos']
    for d in dirs:
        os.makedirs(os.path.join(ROOT_DIR, d), exist_ok=True)
        
    config_file = os.path.join(ROOT_DIR, 'config/setting.json')
    if not os.path.exists(config_file):
        import json
        default_config = {
            'conf': 0.25,
            'iou': 0.45,
            'save_img': False,
            'save_video': False,
            'model': ''
        }
        with open(config_file, 'w') as f:
            json.dump(default_config, f, indent=2)


def main():
    setup_environment()
    os.chdir(ROOT_DIR)
    
    app = QApplication(sys.argv)
    app.setApplicationName("大豆玉米植保移动平台可视化")
    app.setApplicationVersion("1.0.0")
    
    font = QFont("Microsoft YaHei UI", 10)
    app.setFont(font)
    
    from ui import MainWindow
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
