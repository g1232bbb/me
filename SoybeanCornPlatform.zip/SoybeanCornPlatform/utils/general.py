"""
通用工具
"""

import os
import json
from pathlib import Path
from datetime import datetime


def ensure_dir(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_timestamp() -> str:
    return datetime.now().strftime('%Y%m%d_%H%M%S')


def load_json(path: str) -> dict:
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}


def save_json(path: str, data: dict):
    ensure_dir(Path(path).parent)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def list_models(model_dir: str, extensions: list = ['.onnx']) -> list:
    model_dir = Path(model_dir)
    if not model_dir.exists():
        return []
    
    models = []
    for ext in extensions:
        models.extend(model_dir.glob(f'*{ext}'))
    
    models.sort(key=lambda x: x.stat().st_size)
    return [m.name for m in models]


def count_detections(detections: list) -> dict:
    stats = {}
    for det in detections:
        name = det['class_name']
        stats[name] = stats.get(name, 0) + 1
    return stats


class FPSCounter:
    def __init__(self, avg_count: int = 10):
        self.avg_count = avg_count
        self.times = []
        self.last_time = None
        
    def update(self) -> float:
        import time
        current_time = time.time()
        
        if self.last_time is not None:
            self.times.append(current_time - self.last_time)
            if len(self.times) > self.avg_count:
                self.times.pop(0)
                
        self.last_time = current_time
        
        if len(self.times) > 0:
            avg_time = sum(self.times) / len(self.times)
            return 1.0 / avg_time if avg_time > 0 else 0
        return 0
    
    def reset(self):
        self.times = []
        self.last_time = None
