"""
摄像头工具
"""

import cv2


class VideoCapture:
    """视频/摄像头捕获器"""
    
    def __init__(self, source):
        self.source = source
        self.cap = None
        self.is_camera = False
        self.is_rtsp = False
        
    def open(self) -> bool:
        if isinstance(self.source, int):
            self.cap = cv2.VideoCapture(self.source)
            self.is_camera = True
        elif str(self.source).startswith('rtsp://'):
            self.cap = cv2.VideoCapture(self.source)
            self.is_rtsp = True
        else:
            self.cap = cv2.VideoCapture(str(self.source))
            
        return self.cap.isOpened()
    
    def read(self) -> tuple:
        if self.cap is None:
            return False, None
        return self.cap.read()
    
    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None
            
    def get_info(self) -> dict:
        if self.cap is None:
            return None
            
        return {
            'width': int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
            'height': int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            'fps': self.cap.get(cv2.CAP_PROP_FPS),
            'frame_count': int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT)),
            'is_camera': self.is_camera,
            'is_rtsp': self.is_rtsp
        }
    
    @property
    def frame_count(self) -> int:
        if self.cap is None or self.is_camera or self.is_rtsp:
            return -1
        return int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    def __enter__(self):
        self.open()
        return self
    
    def __exit__(self, *args):
        self.release()
