"""
ONNX YOLO 检测器
"""

import cv2
import numpy as np
import onnxruntime as ort
from pathlib import Path


# 大豆玉米植保标签（可根据实际模型修改）
COCO_CLASSES = ['bud', 'flower', 'withered']

# 颜色表
COLORS = np.array([
    [255, 182, 193],   # bud - 粉色
    [255, 0, 0],       # flower - 红色
    [139, 69, 19],     # withered - 褐色
], dtype=np.uint8)


class ONNXDetector:
    """ONNX YOLO 检测器"""
    
    def __init__(self, model_path: str, conf_thres: float = 0.25, iou_thres: float = 0.45):
        self.model_path = model_path
        self.conf_thres = conf_thres
        self.iou_thres = iou_thres
        self.classes = COCO_CLASSES
        self._init_session()
        
    def _init_session(self):
        providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
        available = ort.get_available_providers()
        providers = [p for p in providers if p in available]
        
        sess_options = ort.SessionOptions()
        sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        self.session = ort.InferenceSession(
            self.model_path, 
            sess_options=sess_options,
            providers=providers
        )
        
        self.input_name = self.session.get_inputs()[0].name
        self.input_shape = self.session.get_inputs()[0].shape
        self.input_height = self.input_shape[2]
        self.input_width = self.input_shape[3]
        self.provider = self.session.get_providers()[0]
        
    def preprocess(self, img: np.ndarray) -> tuple:
        img_h, img_w = img.shape[:2]
        ratio = min(self.input_width / img_w, self.input_height / img_h)
        new_w, new_h = int(img_w * ratio), int(img_h * ratio)
        
        resized = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        
        pad_w = (self.input_width - new_w) // 2
        pad_h = (self.input_height - new_h) // 2
        
        padded = np.full((self.input_height, self.input_width, 3), 114, dtype=np.uint8)
        padded[pad_h:pad_h+new_h, pad_w:pad_w+new_w] = resized
        
        input_tensor = padded[:, :, ::-1].transpose(2, 0, 1).astype(np.float32) / 255.0
        input_tensor = np.expand_dims(input_tensor, axis=0)
        
        return input_tensor, ratio, (pad_w, pad_h)
    
    def postprocess(self, outputs: np.ndarray, ratio: float, pad: tuple, orig_shape: tuple) -> list:
        predictions = outputs[0][0].T
        
        boxes = predictions[:, :4]
        scores = np.max(predictions[:, 4:], axis=1)
        class_ids = np.argmax(predictions[:, 4:], axis=1)
        
        mask = scores > self.conf_thres
        boxes = boxes[mask]
        scores = scores[mask]
        class_ids = class_ids[mask]
        
        if len(boxes) == 0:
            return []
        
        boxes_xyxy = self._xywh2xyxy(boxes)
        
        pad_w, pad_h = pad
        boxes_xyxy[:, [0, 2]] = (boxes_xyxy[:, [0, 2]] - pad_w) / ratio
        boxes_xyxy[:, [1, 3]] = (boxes_xyxy[:, [1, 3]] - pad_h) / ratio
        
        boxes_xyxy[:, [0, 2]] = np.clip(boxes_xyxy[:, [0, 2]], 0, orig_shape[1])
        boxes_xyxy[:, [1, 3]] = np.clip(boxes_xyxy[:, [1, 3]], 0, orig_shape[0])
        
        indices = cv2.dnn.NMSBoxes(
            boxes_xyxy.tolist(), 
            scores.tolist(), 
            self.conf_thres, 
            self.iou_thres
        )
        
        detections = []
        for i in indices:
            detections.append({
                'box': boxes_xyxy[i].astype(int).tolist(),
                'score': float(scores[i]),
                'class_id': int(class_ids[i]),
                'class_name': self.classes[class_ids[i]] if class_ids[i] < len(self.classes) else 'unknown'
            })
        
        return detections
    
    def _xywh2xyxy(self, boxes: np.ndarray) -> np.ndarray:
        new_boxes = np.zeros_like(boxes)
        new_boxes[:, 0] = boxes[:, 0] - boxes[:, 2] / 2
        new_boxes[:, 1] = boxes[:, 1] - boxes[:, 3] / 2
        new_boxes[:, 2] = boxes[:, 0] + boxes[:, 2] / 2
        new_boxes[:, 3] = boxes[:, 1] + boxes[:, 3] / 2
        return new_boxes
    
    def detect(self, img: np.ndarray) -> list:
        orig_shape = img.shape[:2]
        input_tensor, ratio, pad = self.preprocess(img)
        outputs = self.session.run(None, {self.input_name: input_tensor})
        detections = self.postprocess(outputs, ratio, pad, orig_shape)
        return detections
    
    def draw_detections(self, img: np.ndarray, detections: list, 
                        line_width: int = 2, font_scale: float = 0.6) -> np.ndarray:
        img = img.copy()
        
        for det in detections:
            x1, y1, x2, y2 = det['box']
            score = det['score']
            class_id = det['class_id']
            class_name = det['class_name']
            
            color = COLORS[class_id % len(COLORS)].tolist()
            
            cv2.rectangle(img, (x1, y1), (x2, y2), color, line_width)
            
            label = f'{class_name} {score:.2f}'
            (label_w, label_h), baseline = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, font_scale, 1
            )
            cv2.rectangle(img, (x1, y1 - label_h - 10), (x1 + label_w, y1), color, -1)
            cv2.putText(img, label, (x1, y1 - 5), 
                       cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), 1)
        
        return img
    
    def get_model_info(self) -> dict:
        return {
            'path': self.model_path,
            'name': Path(self.model_path).stem,
            'input_shape': self.input_shape,
            'provider': self.provider,
            'num_classes': len(self.classes)
        }
