from .onnx_detector import ONNXDetector, COCO_CLASSES, COLORS

__all__ = ['ONNXDetector', 'COCO_CLASSES', 'COLORS']
