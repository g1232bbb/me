"""
主窗口
"""

from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QLabel, QPushButton, QComboBox, QCheckBox, QProgressBar,
    QFileDialog, QMenu, QMessageBox, QApplication
)
from PySide6.QtCore import Qt, QThread, Signal, QPoint
from PySide6.QtGui import QAction
import numpy as np
import os
import time

from .styles import get_full_stylesheet, ACCENT_COLOR
from .widgets import (
    StatsCard, VideoDisplay, SidebarButton, ControlButton, LabeledSlider
)


class DetectionThread(QThread):
    """检测线程"""
    
    frame_ready = Signal(np.ndarray, np.ndarray, list)
    progress = Signal(int)
    status = Signal(str)
    fps_update = Signal(float)
    finished_detection = Signal()
    error = Signal(str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.detector = None
        self.source = None
        self.is_running = False
        self.is_paused = False
        
    def set_detector(self, detector):
        self.detector = detector
        
    def set_source(self, source):
        self.source = source
        
    def run(self):
        if self.detector is None or self.source is None:
            self.error.emit("检测器或输入源未设置")
            return
            
        from utils.camera import VideoCapture
        from utils.general import FPSCounter
        
        self.is_running = True
        fps_counter = FPSCounter(avg_count=10)
        
        try:
            cap = VideoCapture(self.source)
            if not cap.open():
                self.error.emit(f"无法打开: {self.source}")
                return
                
            self.status.emit("检测中...")
            info = cap.get_info()
            total_frames = info['frame_count'] if info['frame_count'] > 0 else -1
            frame_count = 0
            
            while self.is_running:
                if self.is_paused:
                    time.sleep(0.1)
                    continue
                    
                ret, frame = cap.read()
                if not ret:
                    break
                    
                frame_count += 1
                
                detections = self.detector.detect(frame)
                result_frame = self.detector.draw_detections(frame, detections)
                
                self.frame_ready.emit(frame.copy(), result_frame, detections)
                
                fps = fps_counter.update()
                self.fps_update.emit(fps)
                
                if total_frames > 0:
                    progress = int(frame_count / total_frames * 100)
                    self.progress.emit(progress)
                    
            cap.release()
            
        except Exception as e:
            self.error.emit(str(e))
        finally:
            self.is_running = False
            self.finished_detection.emit()
            self.status.emit("检测完成")
            
    def stop(self):
        self.is_running = False
        
    def pause(self):
        self.is_paused = True
        
    def resume(self):
        self.is_paused = False


class MainWindow(QMainWindow):
    """主窗口"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("玫瑰花检测系统")
        self.setMinimumSize(1280, 700)
        
        self.detector = None
        self.current_source = None
        self.is_detecting = False
        
        self.setStyleSheet(get_full_stylesheet())
        self._setup_ui()
        
        self.detection_thread = DetectionThread()
        self._connect_signals()
        
        self._load_config()
        self._refresh_models()
        
    def _setup_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        sidebar = self._create_sidebar()
        main_layout.addWidget(sidebar)
        
        content = self._create_content()
        main_layout.addWidget(content, 1)
        
    def _create_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("sideBar")
        sidebar.setFixedWidth(220)
        
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(15, 20, 15, 20)
        layout.setSpacing(10)
        
        # Logo
        title_layout = QHBoxLayout()
        logo = QLabel("🌹")
        logo.setStyleSheet("font-size: 28px;")
        title = QLabel("玫瑰花检测")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: white;")
        title_layout.addWidget(logo)
        title_layout.addWidget(title)
        title_layout.addStretch()
        layout.addLayout(title_layout)
        
        layout.addSpacing(20)
        
        # 输入源
        source_label = QLabel("输入源")
        source_label.setStyleSheet("color: #6C757D; font-size: 11px; font-weight: bold;")
        layout.addWidget(source_label)
        
        self.btn_file = SidebarButton("本地文件", "📁")
        self.btn_file.clicked.connect(self._open_file)
        layout.addWidget(self.btn_file)
        
        self.btn_camera = SidebarButton("摄像头", "📷")
        self.btn_camera.clicked.connect(self._open_camera)
        layout.addWidget(self.btn_camera)
        
        self.btn_rtsp = SidebarButton("RTSP 流", "🌐")
        self.btn_rtsp.clicked.connect(self._open_rtsp)
        layout.addWidget(self.btn_rtsp)
        
        layout.addSpacing(20)
        
        # 模型
        model_label = QLabel("模型")
        model_label.setStyleSheet("color: #6C757D; font-size: 11px; font-weight: bold;")
        layout.addWidget(model_label)
        
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(40)
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        layout.addWidget(self.model_combo)
        
        layout.addSpacing(20)
        
        # 参数
        params_label = QLabel("参数设置")
        params_label.setStyleSheet("color: #6C757D; font-size: 11px; font-weight: bold;")
        layout.addWidget(params_label)
        
        self.conf_slider = LabeledSlider("置信度", 0.0, 1.0, 0.25, decimals=2)
        self.conf_slider.valueChanged.connect(self._on_conf_changed)
        layout.addWidget(self.conf_slider)
        
        self.iou_slider = LabeledSlider("IOU 阈值", 0.0, 1.0, 0.45, decimals=2)
        self.iou_slider.valueChanged.connect(self._on_iou_changed)
        layout.addWidget(self.iou_slider)
        
        layout.addSpacing(20)
        
        # 保存选项
        save_label = QLabel("保存选项")
        save_label.setStyleSheet("color: #6C757D; font-size: 11px; font-weight: bold;")
        layout.addWidget(save_label)
        
        self.save_img_check = QCheckBox("保存图片")
        layout.addWidget(self.save_img_check)
        
        self.save_video_check = QCheckBox("保存视频")
        layout.addWidget(self.save_video_check)
        
        layout.addStretch()
        
        version = QLabel("v1.0.0 | ONNX Runtime")
        version.setStyleSheet("color: #6C757D; font-size: 10px;")
        version.setAlignment(Qt.AlignCenter)
        layout.addWidget(version)
        
        return sidebar
        
    def _create_content(self) -> QFrame:
        content = QFrame()
        content.setStyleSheet("background-color: #1A1A2E;")
        
        layout = QVBoxLayout(content)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # 统计卡片
        stats_layout = QHBoxLayout()
        stats_layout.setSpacing(15)
        
        self.card_classes = StatsCard("类别数", "--", ACCENT_COLOR)
        self.card_targets = StatsCard("目标总数", "--", "#FB9D8B")
        self.card_fps = StatsCard("FPS", "--", "#AA80D5")
        self.card_model = StatsCard("模型", "--", "#40BAC1")
        self.card_bud = StatsCard("bud", "0", "#FFB6C1")
        self.card_flower = StatsCard("flower", "0", "#FF4444")
        self.card_withered = StatsCard("withered", "0", "#8B4513")
        
        stats_layout.addWidget(self.card_classes)
        stats_layout.addWidget(self.card_targets)
        stats_layout.addWidget(self.card_fps)
        stats_layout.addWidget(self.card_model)
        stats_layout.addWidget(self.card_bud)
        stats_layout.addWidget(self.card_flower)
        stats_layout.addWidget(self.card_withered)
        stats_layout.addStretch()
        
        layout.addLayout(stats_layout)
        
        # 视频显示
        video_container = QFrame()
        video_container.setStyleSheet("background-color: #1F2940; border-radius: 12px;")
        video_layout = QHBoxLayout(video_container)
        video_layout.setContentsMargins(10, 10, 10, 10)
        video_layout.setSpacing(10)
        
        # 原始画面
        original_frame = QFrame()
        original_frame.setStyleSheet("background-color: #0F0F1A; border-radius: 8px;")
        original_layout = QVBoxLayout(original_frame)
        original_layout.setContentsMargins(5, 5, 5, 5)
        
        original_title = QLabel("原始画面")
        original_title.setStyleSheet("color: #6C757D; font-size: 11px;")
        original_title.setAlignment(Qt.AlignCenter)
        original_layout.addWidget(original_title)
        
        self.original_display = VideoDisplay()
        self.original_display.set_placeholder("原始画面")
        original_layout.addWidget(self.original_display)
        
        video_layout.addWidget(original_frame)
        
        # 检测结果
        result_frame = QFrame()
        result_frame.setStyleSheet("background-color: #0F0F1A; border-radius: 8px;")
        result_layout = QVBoxLayout(result_frame)
        result_layout.setContentsMargins(5, 5, 5, 5)
        
        result_title = QLabel("检测结果")
        result_title.setStyleSheet("color: #6C757D; font-size: 11px;")
        result_title.setAlignment(Qt.AlignCenter)
        result_layout.addWidget(result_title)
        
        self.result_display = VideoDisplay()
        self.result_display.set_placeholder("检测结果")
        result_layout.addWidget(self.result_display)
        
        video_layout.addWidget(result_frame)
        
        layout.addWidget(video_container, 1)
        
        # 控制栏
        control_layout = QHBoxLayout()
        control_layout.setSpacing(15)
        
        self.btn_start = ControlButton("▶  开始", "success")
        self.btn_start.clicked.connect(self._toggle_detection)
        control_layout.addWidget(self.btn_start)
        
        self.btn_stop = ControlButton("■  停止", "danger")
        self.btn_stop.clicked.connect(self._stop_detection)
        self.btn_stop.setEnabled(False)
        control_layout.addWidget(self.btn_stop)
        
        self.btn_screenshot = ControlButton("📷  截图", "default")
        self.btn_screenshot.clicked.connect(self._take_screenshot)
        control_layout.addWidget(self.btn_screenshot)
        
        control_layout.addStretch()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setTextVisible(False)
        control_layout.addWidget(self.progress_bar, 1)
        
        layout.addLayout(control_layout)
        
        # 状态栏
        self.status_label = QLabel("就绪")
        self.status_label.setStyleSheet("color: #6C757D; font-size: 12px;")
        layout.addWidget(self.status_label)
        
        return content
        
    def _connect_signals(self):
        self.detection_thread.frame_ready.connect(self._on_frame_ready)
        self.detection_thread.progress.connect(self._on_progress)
        self.detection_thread.status.connect(self._on_status)
        self.detection_thread.fps_update.connect(self._on_fps_update)
        self.detection_thread.finished_detection.connect(self._on_detection_finished)
        self.detection_thread.error.connect(self._on_error)
        
    def _load_config(self):
        from utils.general import load_json
        config = load_json("config/setting.json")
        
        if config:
            self.conf_slider.set_value(config.get('conf', 0.25))
            self.iou_slider.set_value(config.get('iou', 0.45))
            self.save_img_check.setChecked(config.get('save_img', False))
            self.save_video_check.setChecked(config.get('save_video', False))
            
    def _save_config(self):
        from utils.general import save_json
        config = {
            'conf': self.conf_slider.value(),
            'iou': self.iou_slider.value(),
            'save_img': self.save_img_check.isChecked(),
            'save_video': self.save_video_check.isChecked(),
            'model': self.model_combo.currentText()
        }
        save_json("config/setting.json", config)
        
    def _refresh_models(self):
        from utils.general import list_models
        models = list_models("models", ['.onnx'])
        
        self.model_combo.clear()
        if models:
            self.model_combo.addItems(models)
            self._load_model(models[0])
        else:
            self.status_label.setText("未在 'models' 文件夹中找到模型")
            
    def _load_model(self, model_name: str):
        model_path = f"models/{model_name}"
        
        if not os.path.exists(model_path):
            self._on_error(f"模型未找到: {model_path}")
            return
            
        try:
            self.status_label.setText(f"正在加载模型: {model_name}...")
            QApplication.processEvents()
            
            from core import ONNXDetector
            self.detector = ONNXDetector(
                model_path, 
                conf_thres=self.conf_slider.value(),
                iou_thres=self.iou_slider.value()
            )
            
            self.detection_thread.set_detector(self.detector)
            self.card_model.set_value(model_name.replace('.onnx', ''))
            
            info = self.detector.get_model_info()
            self.status_label.setText(f"模型已加载: {model_name} | 运行环境: {info['provider']}")
            
        except Exception as e:
            self._on_error(f"加载模型失败: {e}")
            
    def _open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "打开文件", "",
            "媒体文件 (*.mp4 *.avi *.mkv *.mov *.jpg *.jpeg *.png *.bmp);;所有文件 (*)"
        )
        
        if file_path:
            self.current_source = file_path
            self.status_label.setText(f"已选择: {os.path.basename(file_path)}")
            self._clear_buttons()
            self.btn_file.setChecked(True)
            
    def _open_camera(self):
        """打开摄像头 - 直接显示菜单，不检测"""
        menu = QMenu(self)
        for cam_id in range(4):
            action = QAction(f"摄像头 {cam_id}", self)
            action.triggered.connect(lambda checked, cid=cam_id: self._select_camera(cid))
            menu.addAction(action)
            
        menu.exec(self.btn_camera.mapToGlobal(QPoint(0, self.btn_camera.height())))
        
    def _select_camera(self, camera_id: int):
        self.current_source = camera_id
        self.status_label.setText(f"已选择: 摄像头 {camera_id}")
        self._clear_buttons()
        self.btn_camera.setChecked(True)
        
    def _open_rtsp(self):
        from PySide6.QtWidgets import QInputDialog
        
        rtsp_url, ok = QInputDialog.getText(
            self, "RTSP 流",
            "请输入 RTSP 地址:",
            text="rtsp://admin:password@192.168.1.100:554/stream"
        )
        
        if ok and rtsp_url:
            self.current_source = rtsp_url
            self.status_label.setText(f"已选择: RTSP 流")
            self._clear_buttons()
            self.btn_rtsp.setChecked(True)
            
    def _clear_buttons(self):
        self.btn_file.setChecked(False)
        self.btn_camera.setChecked(False)
        self.btn_rtsp.setChecked(False)
        
    def _toggle_detection(self):
        if self.is_detecting:
            self.detection_thread.pause()
            self.btn_start.setText("▶  继续")
            self.is_detecting = False
        else:
            if self.detection_thread.isRunning():
                self.detection_thread.resume()
                self.btn_start.setText("⏸  暂停")
                self.is_detecting = True
            else:
                self._start_detection()
                
    def _start_detection(self):
        if self.detector is None:
            QMessageBox.warning(self, "警告", "请先加载模型")
            return
            
        if self.current_source is None:
            QMessageBox.warning(self, "警告", "请先选择输入源")
            return
            
        self.detection_thread.set_source(self.current_source)
        self.detection_thread.start()
        
        self.btn_start.setText("⏸  暂停")
        self.btn_stop.setEnabled(True)
        self.is_detecting = True
        
    def _stop_detection(self):
        self.detection_thread.stop()
        self.detection_thread.wait()
        self._reset_ui()
        
    def _reset_ui(self):
        self.btn_start.setText("▶  开始")
        self.btn_stop.setEnabled(False)
        self.is_detecting = False
        self.progress_bar.setValue(0)
        self.original_display.clear_display()
        self.result_display.clear_display()
        self.card_classes.set_value("--")
        self.card_targets.set_value("--")
        self.card_fps.set_value("--")
        self.card_bud.set_value("0")
        self.card_flower.set_value("0")
        self.card_withered.set_value("0")
        
    def _take_screenshot(self):
        if self.result_display.pixmap() and not self.result_display.pixmap().isNull():
            from utils.general import ensure_dir, get_timestamp
            
            save_dir = ensure_dir("outputs/screenshots")
            filename = f"screenshot_{get_timestamp()}.png"
            filepath = save_dir / filename
            
            self.result_display.pixmap().save(str(filepath))
            self.status_label.setText(f"截图已保存: {filename}")
        else:
            self.status_label.setText("没有可截取的画面")
            
    def _on_model_changed(self, model_name: str):
        if model_name:
            self._load_model(model_name)
            
    def _on_conf_changed(self, value: float):
        if self.detector:
            self.detector.conf_thres = value
            
    def _on_iou_changed(self, value: float):
        if self.detector:
            self.detector.iou_thres = value
            
    def _on_frame_ready(self, original: np.ndarray, result: np.ndarray, detections: list):
        self.original_display.set_frame(original)
        self.result_display.set_frame(result)
        
        from utils.general import count_detections
        stats = count_detections(detections)
        
        self.card_classes.set_value(str(len(stats)))
        self.card_targets.set_value(str(len(detections)))
        
        # 更新各类别统计
        self.card_bud.set_value(str(stats.get('bud', 0)))
        self.card_flower.set_value(str(stats.get('flower', 0)))
        self.card_withered.set_value(str(stats.get('withered', 0)))
        
    def _on_progress(self, value: int):
        self.progress_bar.setValue(value)
        
    def _on_status(self, message: str):
        self.status_label.setText(message)
        
    def _on_fps_update(self, fps: float):
        self.card_fps.set_value(f"{fps:.1f}")
        
    def _on_detection_finished(self):
        self._reset_ui()
        
    def _on_error(self, message: str):
        self.status_label.setText(f"错误: {message}")
        QMessageBox.critical(self, "错误", message)
        
    def closeEvent(self, event):
        if self.detection_thread.isRunning():
            self.detection_thread.stop()
            self.detection_thread.wait()
        self._save_config()
        event.accept()
