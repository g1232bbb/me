"""
自定义控件
"""

from PySide6.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, 
    QFrame, QPushButton, QSizePolicy, QGraphicsDropShadowEffect, QSlider
)
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap, QImage, QColor
import numpy as np
import cv2


class StatsCard(QFrame):
    """统计卡片"""
    
    def __init__(self, title: str, value: str = "--", color: str = "#4ECDC4", parent=None):
        super().__init__(parent)
        self.color = color
        self._setup_ui(title, value)
        
    def _setup_ui(self, title: str, value: str):
        self.setStyleSheet("""
            QFrame {
                background-color: #1F2940;
                border-radius: 10px;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 12, 15, 12)
        layout.setSpacing(5)
        
        self.value_label = QLabel(value)
        self.value_label.setAlignment(Qt.AlignCenter)
        self.value_label.setStyleSheet(f"color: {self.color}; font-size: 28px; font-weight: bold;")
        layout.addWidget(self.value_label)
        
        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setStyleSheet("color: #B0B0B0; font-size: 11px;")
        layout.addWidget(self.title_label)
        
        self.setMinimumSize(100, 80)
        self.setMaximumHeight(90)
        
    def set_value(self, value: str):
        self.value_label.setText(str(value))


class VideoDisplay(QLabel):
    """视频显示"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(320, 240)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setStyleSheet("""
            background-color: #000000;
            border-radius: 8px;
            color: #666666;
            font-size: 14px;
        """)
        self._default_text = "No Video"
        self.setText(self._default_text)
        
    def set_frame(self, frame: np.ndarray):
        if frame is None:
            self.clear_display()
            return
            
        w, h = self.width(), self.height()
        if w <= 0 or h <= 0:
            return
            
        img_h, img_w = frame.shape[:2]
        scale = min(w / img_w, h / img_h)
        new_w, new_h = int(img_w * scale), int(img_h * scale)
        
        resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        rgb_frame = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        h, w, ch = rgb_frame.shape
        bytes_per_line = ch * w
        qimg = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.setPixmap(QPixmap.fromImage(qimg))
        
    def clear_display(self):
        self.clear()
        self.setText(self._default_text)
        
    def set_placeholder(self, text: str):
        self._default_text = text
        if self.pixmap() is None or self.pixmap().isNull():
            self.setText(text)


class SidebarButton(QPushButton):
    """侧边栏按钮"""
    
    def __init__(self, text: str, icon_text: str = "", parent=None):
        super().__init__(parent)
        self.setText(f"  {icon_text}  {text}" if icon_text else f"  {text}")
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(45)
        self.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #B0B0B0;
                border: none;
                border-radius: 8px;
                text-align: left;
                padding-left: 15px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
            }
            QPushButton:checked {
                background-color: #6B80D2;
                color: #FFFFFF;
            }
        """)


class ControlButton(QPushButton):
    """控制按钮"""
    
    def __init__(self, text: str, button_type: str = "default", parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumSize(80, 40)
        
        colors = {
            "default": ("#0F3460", "#6B80D2"),
            "success": ("#5CB85C", "#7CD37C"),
            "danger": ("#D9534F", "#E87C79"),
        }
        
        bg, hover = colors.get(button_type, colors["default"])
        
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 25px;
                font-size: 13px;
                font-weight: 500;
            }}
            QPushButton:hover {{
                background-color: {hover};
            }}
            QPushButton:disabled {{
                background-color: #2A2A3E;
                color: #6C757D;
            }}
        """)


class LabeledSlider(QWidget):
    """带标签的滑块"""
    
    valueChanged = Signal(float)
    
    def __init__(self, label: str, min_val: float, max_val: float, 
                 default: float, decimals: int = 2, parent=None):
        super().__init__(parent)
        
        self.min_val = min_val
        self.max_val = max_val
        self.decimals = decimals
        self.multiplier = 10 ** decimals
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        
        label_layout = QHBoxLayout()
        self.label = QLabel(label)
        self.label.setStyleSheet("color: #B0B0B0; font-size: 12px;")
        self.value_label = QLabel(f"{default:.{decimals}f}")
        self.value_label.setStyleSheet("color: #4ECDC4; font-size: 12px; font-weight: bold;")
        label_layout.addWidget(self.label)
        label_layout.addStretch()
        label_layout.addWidget(self.value_label)
        layout.addLayout(label_layout)
        
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(int(min_val * self.multiplier))
        self.slider.setMaximum(int(max_val * self.multiplier))
        self.slider.setValue(int(default * self.multiplier))
        self.slider.valueChanged.connect(self._on_value_changed)
        self.slider.setStyleSheet("""
            QSlider::groove:horizontal {
                height: 6px;
                background: #0F3460;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                width: 16px;
                height: 16px;
                margin: -5px 0;
                background: #6B80D2;
                border-radius: 8px;
            }
            QSlider::sub-page:horizontal {
                background: #6B80D2;
                border-radius: 3px;
            }
        """)
        layout.addWidget(self.slider)
        
    def _on_value_changed(self, value: int):
        real_value = value / self.multiplier
        self.value_label.setText(f"{real_value:.{self.decimals}f}")
        self.valueChanged.emit(real_value)
        
    def value(self) -> float:
        return self.slider.value() / self.multiplier
    
    def set_value(self, value: float):
        self.slider.setValue(int(value * self.multiplier))
