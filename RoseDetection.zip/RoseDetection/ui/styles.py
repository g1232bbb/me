"""
UI 样式表
"""

PRIMARY_COLOR = "#6B80D2"
SECONDARY_COLOR = "#B48CFF"
ACCENT_COLOR = "#4ECDC4"

STYLESHEET = """
QMainWindow {
    background-color: #1A1A2E;
}

QWidget {
    font-family: "Microsoft YaHei UI", "Segoe UI", sans-serif;
    font-size: 12px;
    color: #FFFFFF;
}

QFrame#sideBar {
    background-color: #16213E;
    border-right: 1px solid #0F3460;
}

QComboBox {
    background-color: #0F3460;
    color: #FFFFFF;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    min-width: 120px;
}

QComboBox:hover {
    background-color: #1F2940;
}

QComboBox::drop-down {
    border: none;
    padding-right: 10px;
}

QComboBox QAbstractItemView {
    background-color: #16213E;
    color: #FFFFFF;
    selection-background-color: #6B80D2;
    border: 1px solid #0F3460;
    border-radius: 6px;
    padding: 4px;
}

QCheckBox {
    color: #B0B0B0;
    spacing: 8px;
}

QCheckBox::indicator {
    width: 20px;
    height: 20px;
    border-radius: 4px;
    border: 2px solid #0F3460;
    background-color: transparent;
}

QCheckBox::indicator:checked {
    background-color: #6B80D2;
    border-color: #6B80D2;
}

QProgressBar {
    background-color: #0F3460;
    border: none;
    border-radius: 4px;
    height: 8px;
}

QProgressBar::chunk {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #6B80D2, stop:1 #B48CFF);
    border-radius: 4px;
}

QMenu {
    background-color: #16213E;
    color: #FFFFFF;
    border: 1px solid #0F3460;
    border-radius: 6px;
    padding: 5px;
}

QMenu::item {
    padding: 8px 20px;
    border-radius: 4px;
}

QMenu::item:selected {
    background-color: #6B80D2;
}
"""


def get_full_stylesheet() -> str:
    return STYLESHEET
